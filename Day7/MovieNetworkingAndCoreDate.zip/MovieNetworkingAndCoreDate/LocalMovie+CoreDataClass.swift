//
//  LocalMovie+CoreDataClass.swift
//  
//
//  Created by Esraa Hassan on 4/1/20.
//
//

import Foundation
import CoreData

@objc(LocalMovie)
public class LocalMovie: NSManagedObject {

}
