//
//  RemoteMovie+CoreDataClass.swift
//  
//
//  Created by Esraa Hassan on 4/1/20.
//
//

import Foundation
import CoreData

@objc(RemoteMovie)
public class RemoteMovie: NSManagedObject {

}
