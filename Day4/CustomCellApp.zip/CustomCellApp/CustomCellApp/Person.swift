//
//  Person.swift
//  CustomCellApp
//
//  Created by Esraa Hassan on 3/29/20.
//  Copyright © 2020 Jets. All rights reserved.
//

import Foundation

struct Person{
    var name: String
    var age: Int
    var image: String
}
